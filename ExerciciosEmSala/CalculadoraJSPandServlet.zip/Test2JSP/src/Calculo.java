import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Calculo", urlPatterns = "/Calculo")
public class Calculo extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        double v1 = Double.parseDouble(request.getParameter("value1"));
        double v2 = Double.parseDouble(request.getParameter("value2"));
        String type = request.getParameter("type");
        Double result = null;

        switch (type) {
            case "+": result = v1 + v2; break;
            case "-": result = v1 - v2; break;
            case "*": result = v1 * v2; break;
            case "/": result = v1 / v2; break;
        }

        if (type.equals("/") && v2 == 0) {
            request.setAttribute("div_by_zero", true);
        } else {
            request.setAttribute("exp", "" + v1 + " " + type + " " + v2 + " = " + result);
        }

        request.getRequestDispatcher("index.jsp").forward(request, response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
