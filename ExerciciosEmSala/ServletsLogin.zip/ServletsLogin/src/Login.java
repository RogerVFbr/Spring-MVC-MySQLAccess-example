import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@WebServlet(name = "Login", urlPatterns = "/Login")
public class Login extends HttpServlet {

    private static Map users = Stream.of(new String[][] {
            { "123@123", "java" }
    }).collect(Collectors.toMap(data -> data[0], data -> data[1]));


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String login = request.getParameter("login");
        String password = request.getParameter("password");

        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("Credentials sent: " + request.getParameter("login") + " / " +
                request.getParameter("password") + "</br>");

        if (users.containsKey(login) && users.get(login).equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("login", login);
            RequestDispatcher rd = request.getRequestDispatcher("/Principal");
            rd.forward(request, response);
//            out.println("User successfully logged in and initiated session.</br>");
        } else {

        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
